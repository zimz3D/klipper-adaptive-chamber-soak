# klipper-adaptive-chamber-soak

> **Safety and liability notice**
>
> This software controls or influences chamber-heating behavior. Improper configuration, installation, or use may cause equipment damage, fire, personal injury, or property loss. You are solely responsible for assessing suitability, verifying all hardware and temperature limits, installing and configuring the software correctly, supervising operation, and maintaining appropriate independent safety protections. This project is provided “as is,” without warranty. To the fullest extent permitted by applicable law, the authors and contributors disclaim liability for damage, injury, loss, or claims arising from the software or its use. Do not rely on this software as a substitute for hardware safety controls or safe operating practices.

Klipper add-on that replaces a fixed chamber soak with a temperature-stability check. The core command is usable from Klipper macros, with a RatOS-specific integration described below.

## Klipper add-on

The target temperature comes from the caller, such as the slicer-driven RatOS startup macro. Timing, sensor name, and temperature tolerances can be customized in the `[chamber_equilibrium]` section of `printer.cfg`:

```ini
[chamber_equilibrium]
sensor: temperature_sensor chamber
initial_delay: 480
interval: 300
target_tolerance: 3
stability_tolerance: 3
max_wait: 5400
```

Values are in seconds for the delays and timeout, and degrees Celsius for the tolerances. Defaults give an 8-minute first sample, 5-minute intervals, a minimum temperature of target minus 3 C, a maximum 3 C change between adjacent readings, and a 90-minute fail-closed timeout. The `WAIT_CHAMBER_EQUILIBRIUM` command can also override these defaults per call using `SENSOR`, `INITIAL_DELAY`, `INTERVAL`, `TARGET_TOLERANCE`, `STABILITY_TOLERANCE`, and `MAX_WAIT`.

## RatOS-specific integration

The supplied RatOS startup macro includes a fixed 20-minute soak path. Add this variable to the existing `[gcode_macro RatOS]` section in `printer.cfg` to disable that RatOS soak and replace it with the adaptive path:

```ini
# Adaptive Heat Soak
variable_beacon_adaptive_heat_soak: False
```

The existing `[gcode_macro RatOS]` section is usually already defined, so add only the comment and variable inside it. Do not add a duplicate section. Use `False` exactly as shown for this setup.

## RatOS hardware checks before enabling

Your supplied RatOS macro requests a 150 C chamber-heater preheat, while the supplied Klipper heater `max_temp` is 80 C. This package explicitly ignores the 150 C request and sets `variable_chamber_heater_preheating_temp: 80`, retaining the existing 80 C `max_temp`. Klipper rejects heater targets above `max_temp`. The printing target plus RatOS heating offset must also stay at or below 80 C or Klipper will reject it. The 80 C limit itself still needs to match the heater, sensor, wiring, and chamber materials' manufacturer ratings before enabling heat.

The supplied snippets do not include the chamber heater section or verify_heater values, so this package cannot safely rewrite those values. Restore conservative `verify_heater` settings appropriate to the installed hardware and follow Klipper/RatOS documentation. The duplicate PF4 thermistor must be resolved by confirming which physical sensor is wired to PF4 and keeping exactly one active pin assignment. Do not change sensor type or pin based on guesswork.

## Files and destinations

- `chamber_equilibrium.py` → Klipper `klippy/extras/chamber_equilibrium.py` on the printer host. Common RatOS path is `/home/pi/klipper/klippy/extras/`.
- `chamber_equilibrium.cfg` → printer configuration directory, commonly `~/printer_data/config/`.
- `chamber_heater_override.cfg` → reference patch for the existing RatOS `_CHAMBER_HEATER_ON` macro. Apply the two documented edits to a copy of the existing macro. Do not add a duplicate `[gcode_macro _CHAMBER_HEATER_ON]` section. Preserve RatOS fan, bed, toolhead movement, filter, post-preheat, and delayed-control code.

## Backup and install

1. In Mainsail/Fluidd, download a backup of `printer.cfg` and the RatOS chamber-heater configuration file that defines `_CHAMBER_HEATER_ON`. Also save the current `klippy.log`.
2. Upload `chamber_equilibrium.py` to `/home/pi/klipper/klippy/extras/` and `chamber_equilibrium.cfg` to `~/printer_data/config/`.
3. Include `chamber_equilibrium.cfg` from `printer.cfg` using its actual config path, for example `[include chamber_equilibrium.cfg]`. Set the sensor and timing values in that file as needed. Klipper loads the Python extra through its `[chamber_equilibrium]` section.
4. Apply the macro edits described in `chamber_heater_override.cfg` to the existing macro copy in your user config, ensuring the include order loads your customized definition in place of the RatOS definition. Config section override behavior depends on your RatOS version. Validate duplicate-section handling before restarting.
5. In the `[gcode_macro RatOS]` settings override, set `variable_chamber_heater_preheating_temp: 80`. This disregards the old 150 C request. Keep the heater `max_temp: 80` unchanged. Resolve the printing offset and duplicate PF4 as described above before using chamber heat.
6. Restart Klipper. If it fails to start, restore the backed-up configs and remove the Python extra.

## Checks

With heaters disabled and the printer cold, run `HELP WAIT_CHAMBER_EQUILIBRIUM` to confirm the command is registered. Do not run a real heater cycle until the heater limit, preheat target, printing offset, verify_heater values, and PF4 sensor assignment have been checked. During supervised testing, use a low slicer chamber target within the hardware-approved range, verify the first reading is after 8 minutes, subsequent readings are 5 minutes apart, and startup errors after 90 minutes if the pass criteria are not met. Confirm bed/fan behavior and post-preheat chamber control match the original RatOS sequence.
